const products = [
    { id: 1, name: "Mobile Phone", des: "This smartphone offers fast performance.", price: 200, img: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400" },
    { id: 2, name: "Headphone", des: "This headphones deliver clear sound.", price: 50, img: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400" },
    { id: 3, name: "Laptop", des: "This laptop offers powerful performance.", price: 800, img: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400" },
    { id: 4, name: "Smart Watch", des: "This smartwatch helps you track fitness.", price: 100, img: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400" },
    { id: 5, name: "Mechanical Keyboard", des: "Best for typing and gaming.", price: 20, img: "https://media.wired.com/photos/65b0438c22aa647640de5c75/1:1/w_1800,h_1800,c_limit/Mechanical-Keyboard-Guide-Gear-GettyImages-1313504623.jpg" },
    { id: 6, name: "Mouse Pad", des: "Smooth surface for precise control.", price: 5, img: "https://www.techlandbd.com/storage/cbs/uploads/products/P0122506022/cover.jpg" }
];

let cart = [];
let discountRate = 0; // 0 means no discount, 0.1 means 10%, 0.5 means 50%

// --- Display Products ---
function displayProducts() {
    const productContainer = document.getElementById("product-list");
    
    for (let i = 0; i < products.length; i++) {
        const product = products[i];
        productContainer.innerHTML += `
            <div class="col-md-6 mb-4">
                <div class="card h-100">
                    <img src="${product.img}" class="card-img-top product-img" alt="${product.name}">
                    <div class="card-body">
                        <h5 class="card-title">${product.name}</h5>
                        <p class="small text-muted">${product.des}</p>
                        <p class="card-text"><b>Price:</b> $${product.price}</p>
                        <button class="btn btn-primary w-100" onclick="addToCart(${product.id})">Add to Cart</button>
                    </div>
                </div>
            </div>
        `;
    }
}

// --- Add To Cart ---
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1; 
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    }

    updateCartUI(); 
    
    // Auto open cart when first item added (Optional UX)
    const cartSection = document.getElementById("cart-section");
    if(cartSection.style.display === "none") cartSection.style.display = "block";
}

// --- Update Cart UI (Modified for Discount) ---
function updateCartUI() {
    const cartList = document.getElementById("cart-items");
    const subtotalElement = document.getElementById("subtotal-price");
    const discountElement = document.getElementById("discount-amount");
    const totalPriceElement = document.getElementById("total-price");
    const cartCountElement = document.getElementById("cart-count");

    cartList.innerHTML = ""; 
    let subtotal = 0;
    let totalCount = 0;

    cart.forEach((item) => {
        subtotal += item.price * item.quantity;
        totalCount += item.quantity;

        cartList.innerHTML += `
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <strong>${item.name}</strong><br>
                    <small>$${item.price} x ${item.quantity}</small>
                </div>
                <div>
                    <button class="btn btn-sm btn-secondary" onclick="changeQuantity(${item.id}, -1)">-</button>
                    <span class="mx-2">${item.quantity}</span>
                    <button class="btn btn-sm btn-secondary" onclick="changeQuantity(${item.id}, 1)">+</button>
                </div>
            </li>
        `;
    });

    if (cart.length === 0) {
        cartList.innerHTML = "<li class='list-group-item text-center'>Cart is empty</li>";
    }

    // Calculations
    let discountAmount = subtotal * discountRate;
    let finalTotal = subtotal - discountAmount;

    // Update HTML
    subtotalElement.innerText = subtotal.toFixed(2);
    discountElement.innerText = discountAmount.toFixed(2);
    totalPriceElement.innerText = finalTotal.toFixed(2);
    cartCountElement.innerText = totalCount;
}

// --- Change Quantity ---
function changeQuantity(id, amount) {
    const item = cart.find(item => item.id === id);

    if (item) {
        item.quantity += amount;
        if (item.quantity <= 0) {
            cart = cart.filter(p => p.id !== id);
        }
    }
    updateCartUI();
}

// --- NEW FEATURE: Apply Promo Code ---
function applyPromoCode() {
    const promoInput = document.getElementById("promo-code-input").value.trim();
    const promoMessage = document.getElementById("promo-message");

    // Requirement 5: Ensure promo code can only be applied once
    if (discountRate > 0) {
        promoMessage.innerText = "Promo code already applied!";
        promoMessage.className = "small mt-1 text-danger";
        return;
    }

    // Requirement 2: Accept specific codes
    if (promoInput === "ostad10") {
        discountRate = 0.10; // 10%
        promoMessage.innerText = "Success! 10% discount applied.";
        promoMessage.className = "small mt-1 text-success";
    } 
    else if (promoInput === "ostad50") {
        discountRate = 0.50; // 50%
        promoMessage.innerText = "Success! 50% discount applied.";
        promoMessage.className = "small mt-1 text-success";
    } 
    else {
        // Requirement 4: Invalid Code
        promoMessage.innerText = "Invalid Promo Code";
        promoMessage.className = "small mt-1 text-danger";
        return;
    }

    // Requirement 3: Update total dynamically
    updateCartUI();
}

// --- Clear Cart ---
function clearCart() {
    cart = [];
    discountRate = 0; // Reset discount
    document.getElementById("promo-code-input").value = "";
    document.getElementById("promo-message").innerText = "";
    updateCartUI();
}

// --- Checkout ---
function checkout() {
    if (cart.length > 0) {
        const finalPrice = document.getElementById("total-price").innerText;
        alert("Thanks for purchasing! Total Bill: $" + finalPrice);
        
        // Reset everything
        clearCart(); 
        toggleCart(); 
    } else {
        alert("Your cart is empty!");
    }
}

// --- Toggle Cart ---
function toggleCart() {
    const cartSection = document.getElementById("cart-section");
    if (cartSection.style.display === "none") {
        cartSection.style.display = "block";
    } else {
        cartSection.style.display = "none";
    }
}

// Initialize
displayProducts();